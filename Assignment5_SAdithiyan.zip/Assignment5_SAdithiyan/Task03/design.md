# Task A3 – Design with Abstract Classes

```cpp
class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill&) const = 0;
};
```

- `SelfPay`: returns 0 covered; patient pays the full bill.
- `Insurance`: stores cover limit and co-payment percentage; covered amount is `min(bill.total(), limit) * (1 - copay/100)`.
- `GovernmentScheme`: looks up a fixed package rate and throws `UnknownPackageError` for an unknown code.
- Extension: add `CorporateTieUp : public Payer` and implement its policy. Existing payer classes and the processing loop remain unchanged.

Alternative: store a function pointer or `std::function` policy. Captured state can store limits and percentages. Constant-time policy calls are O(1), like virtual calls; callable storage may include target and captured-state overhead.
