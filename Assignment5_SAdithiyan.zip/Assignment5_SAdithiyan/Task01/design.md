# Task A1 – Design the Polymorphic Bill Hierarchy

## Common interface
Every bill provides `total()`, `type()` and `print()`. Common data includes patient name/identifier and bill number. Category-specific charge data belongs in derived classes.

## UML-style hierarchy
```text
Bill (abstract)
- patient : string
+ total() : double {pure virtual}
+ type() : string {virtual}
+ print() : void
+ ~Bill() {virtual}
  |-- OutPatientBill
  |-- InPatientBill
  |-- DayCareBill
  `-- EmergencyBill
```
Every derived class overrides `total()` and `type()`.

## Pseudocode
```text
ALGORITHM CalculateDailyTotal
INPUT bills[0...n-1] as Bill pointers
SET dayTotal <- 0
FOR i <- 0 TO n-1
    dayTotal <- dayTotal + bills[i]->total()
END FOR
OUTPUT dayTotal
END ALGORITHM
```

## Alternative: type field and switch
One structure stores a type tag and all possible fields; `total()` switches on the tag. Both approaches total n bills in O(n). The switch design requires central code changes when a new type is added. A derived class can be added without changing the polymorphic processing loop. A tagged structure can reserve unused fields; polymorphic objects commonly carry a vptr (implementation-dependent).
