#include <chrono>
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>

struct Base {
    int kind;
    double a, b;
    virtual ~Base() = default;
    virtual double total() const = 0;
};
struct OP : Base {
    OP(double x, double y) { kind=0; a=x; b=y; }
    double total() const override { return a+b; }
};
struct IP : Base {
    IP(double x, double y) { kind=1; a=x; b=y; }
    double total() const override { return a*3+b; }
};
struct Record { int kind; double a,b; };
double switchTotal(const Record& x) {
    switch(x.kind) {
        case 0: return x.a+x.b;
        default: return x.a*3+x.b;
    }
}
template<class F>
long long measure(F f) {
    const auto start=std::chrono::steady_clock::now();
    volatile double checksum=f();
    const auto stop=std::chrono::steady_clock::now();
    std::cout << "checksum=" << checksum << ' ';
    return std::chrono::duration_cast<std::chrono::microseconds>(stop-start).count();
}
int main(int argc, char** argv) {
    const int n = argc > 1 ? std::max(1, std::atoi(argv[1])) : 1000000;
    std::vector<Record> plain; plain.reserve(n);
    std::vector<Base*> poly; poly.reserve(n);
    for(int i=0;i<n;++i) {
        const double x=(i%100)+10, y=(i%50)+5;
        if(i%2==0) { plain.push_back({0,x,y}); poly.push_back(new OP(x,y)); }
        else { plain.push_back({1,x,y}); poly.push_back(new IP(x,y)); }
    }
    auto t1=measure([&](){ double s=0; for(const auto& x:plain) s+=switchTotal(x); return s; });
    auto t2=measure([&](){ double s=0; for(const auto* x:poly) s+=x->total(); return s; });
    std::cout << "\nswitch_us=" << t1 << "\nvirtual_us=" << t2 << '\n';
    for(auto* p:poly) delete p;
}
