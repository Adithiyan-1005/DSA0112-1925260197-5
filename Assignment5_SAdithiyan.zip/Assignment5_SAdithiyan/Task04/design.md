# Task A4 – Design the Exception Strategy

## Error catalogue
| Condition | Suggested exception |
|---|---|
| Negative charges | `InvalidChargeError` / `std::invalid_argument` |
| Claim above cover | `ClaimError` |
| Unknown scheme package | `UnknownPackageError` |
| Missing patient | `MissingPatientError` |
| Allocation failure | `std::bad_alloc` |

Suggested hierarchy: `std::exception -> std::runtime_error -> BillingError -> specific billing errors`.

Validation, construction, package lookup and claim approval may throw. Mark a function `noexcept` only when it truly cannot throw. Destructors should not throw because an exception escaping during stack unwinding can terminate the program.

Alternative: return a `Status` enum or result object. Per-call work is O(1), but every caller must inspect and propagate status. Result objects may store a status and message. Return codes suit expected routine outcomes; exceptions suit exceptional failures.
