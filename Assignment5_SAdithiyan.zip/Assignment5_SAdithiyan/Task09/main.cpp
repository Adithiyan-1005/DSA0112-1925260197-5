#include <iostream>
#include <memory>
#include <string>
#include <vector>
class Bill {
protected:
    std::string patient;
public:
    explicit Bill(std::string p) : patient(std::move(p)) {}
    virtual ~Bill() = default;
    virtual double total() const = 0;
    virtual const char* type() const = 0;
    void print() const { std::cout << type() << ' ' << patient << ": " << total() << '\n'; }
};
class OutPatient : public Bill {
    double consult, tests;
public:
    OutPatient(std::string p,double c,double t):Bill(std::move(p)),consult(c),tests(t){}
    double total() const override { return consult+tests; }
    const char* type() const override { return "OP"; }
};
class DayCareBill : public Bill {
    double package;
public:
    DayCareBill(std::string p,double amount):Bill(std::move(p)),package(amount){}
    double total() const override { return package; }
    const char* type() const override { return "DAYCARE"; }
};
class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill&) const = 0;
};
class CorporateTieUp : public Payer {
    double percent;
public:
    explicit CorporateTieUp(double p):percent(p){}
    double amountCovered(const Bill& b) const override { return b.total()*percent/100.0; }
};
int main() {
    std::vector<std::unique_ptr<Bill>> bills;
    bills.push_back(std::make_unique<OutPatient>("Ravi",500,1200));
    bills.push_back(std::make_unique<DayCareBill>("Meena",18000));
    CorporateTieUp corporate(80);
    for(const auto& b:bills) {
        b->print();
        std::cout << "Corporate cover: " << corporate.amountCovered(*b) << '\n';
    }
}
